public class JuezSalida {

    boolean listosParaEmpezar = false;
 
    
    public synchronized void esperarSalida(){

        if (listosParaEmpezar = false) {
            try {
               wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void darSalida(){

        listosParaEmpezar = true;

        try {
            Thread.currentThread().notifyAll();

        } catch (Exception e) {
        }
        
    }
}
