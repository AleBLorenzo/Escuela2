package com.example;

public interface ObservadorMensajes {

      void onMensajeRecibido(String mensaje);

}
