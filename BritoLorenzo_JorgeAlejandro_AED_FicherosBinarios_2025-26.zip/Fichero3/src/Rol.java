package Fichero3.src;

public enum Rol{
 ADMIN, USER, GUEST
}
