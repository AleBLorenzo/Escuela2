package Fichero3.src;

public enum Combustible {
     GASOLINA, DIESEL, HIBRIDO, ELECTRICO
}
