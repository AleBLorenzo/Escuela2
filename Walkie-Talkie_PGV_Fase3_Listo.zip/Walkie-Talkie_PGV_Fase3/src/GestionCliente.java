
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

//Creamos la clase GestionCliente con la interfaz runable q implementa run 
// Aca ponemos la logica de ejecion para q cada ves q se llame a un cliente haga esta logica y poder hacerlo con varios 
// ya q cone sta clase puedo poner de entrada varios de ellos.

public class GestionCliente implements Runnable {

    Scanner sc = new Scanner(System.in);

    private static List<PrintWriter> listaclientes;
    private Socket cliente;
    private String Nombre;

    public GestionCliente(Socket cliente, List<PrintWriter> listaclientes, String Nombre) {
        this.cliente = cliente;
        this.listaclientes = listaclientes;
        this.Nombre = Nombre;

    }

    public Socket getCliente() {
        return cliente;
    }

    public void setCliente(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {

        try (BufferedReader buffer = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
                OutputStream salida = cliente.getOutputStream();
                PrintWriter escritor = new PrintWriter(salida, true)) {

            listaclientes.add(escritor);

                 String datos;
              
              while ((datos = buffer.readLine())!= null) { 
                  
             

                if (datos.toLowerCase().equals("adios")) {

                    System.out.println("Connexion apagada");
                    System.out.println("Mensaje recibido: " + datos.toString());

                    listaclientes.remove(escritor);
                    break;

                } else {
                    Broadcast(datos, Nombre);

                }

            }

        } catch (IOException e) {
            System.out.println("Error" + e.getMessage());

        }

    }

    public List<PrintWriter> getListaclientes() {
        return listaclientes;
    }

    public void setListaclientes(List<PrintWriter> listaclientes) {
        this.listaclientes = listaclientes;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public static void Broadcast(String mensaje,String Nombre) {

        for (PrintWriter pw : listaclientes) {

            pw.println(Nombre +" : "+mensaje);
        }
    }
}
