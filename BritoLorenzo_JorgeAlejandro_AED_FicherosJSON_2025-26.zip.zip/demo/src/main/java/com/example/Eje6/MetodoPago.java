package com.example.Eje6;

public enum MetodoPago {

   EFECTIVO, TARJETA, TRANSFERENCIA
}
