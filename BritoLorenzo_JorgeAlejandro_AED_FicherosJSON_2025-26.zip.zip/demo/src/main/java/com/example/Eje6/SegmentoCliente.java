package com.example.Eje6;

public enum SegmentoCliente {

   BASICO , PREMIUN

}
