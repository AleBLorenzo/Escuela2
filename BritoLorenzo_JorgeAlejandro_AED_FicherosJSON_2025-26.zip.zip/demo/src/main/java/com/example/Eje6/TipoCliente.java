package com.example.Eje6;

public enum TipoCliente {

     NORMAL, EMPRESA, PARTICULAR

}
